<?php
header('Access-Control-Allow-Origin: *');
error_reporting(0);
require_once 'api/prepare.php';

if (!$_REQUEST['ext']) {
    die('no extension specified');
}

$uuid = $ext_uuid[$_REQUEST['ext']];

switch ($_REQUEST['command']) {
    case 'hangup':
        $command = 'uuid_kill ' . $uuid;
        break;
    case 'bridge':
        if (!$_REQUEST['ext_bridge']) {
            echo 'Missing second extension!';
            exit;
        }
        $command = 'uuid_bridge ' . $uuid . ' ' . $ext_uuid[$_REQUEST['ext_bridge']];
        break;
    case 'hold':
        $command = 'uuid_hold ' . $uuid;
        break;
    case 'unhold':
        $command = 'uuid_hold off ' . $uuid;
        break;
    case 'autovm':
        $command = 'uuid_dual_transfer ' . $uuid . ' * 666' . $_REQUEST['file'];
        break;
    case 'transfer':
        if (isset($_REQUEST['transferto'])) {
            $command = 'uuid_dual_transfer ' . $uuid . ' - ' . $_REQUEST['transferto'];
            break;
        } else {
            echo 'Missing extension to transfer to!';
            exit;
            break;
        }
        break;
}

var_dump($ext_uuid);

echo json_encode(array('response' => trim(event_socket_request($fp, $command))));